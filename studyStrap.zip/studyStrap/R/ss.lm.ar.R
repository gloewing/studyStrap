# Covariate-Matched Study Strap (Accept/reject)

cmss.lm <- function(data, formula = Y ~., target.study, sim.fn = NA, converge.lim = 50000,
                bag.size = length(unique(data$Study)), max.straps = 150, paths = 5,
                stack = "standard", sim.covs = NA, pcr.model = FALSE, PComps = ncol(data) - 2,
                sim.mets = TRUE, model = TRUE, meanSampling = FALSE){
    # Takes data that has the following columns in this order: "Study", "Y", "V_1", ...., "V_p"
        # must be ordered in that way and must include "Study" and "Y", the names of the covariates can vary
    # data is a dataset that includes data$Study (integers indicating study number)
    # should not include rows of target study
    # testStudy is the study number of the target
    # paths is the number of random paths to sample
    # converge.lim is the number of random samples to take before ending the path
    # should include target study
    # formula is the command for the model (not including first two columns
    # -- these are automatically removed during modelling step)
    # stack is the type of stacking procedure to be used - "standard" uses the full dataframe
    # "ss" - uses all the rows from all study straps
    # sim.covs is a vector of the column numbers or a vector of the names of the covariates
        # to be used in the similarity measure
        # default is to use all covariates
    # target.study should be ONLY the design matrix of the target study (no outcome (Y), no Study labels)
    # pcr.model determines whether to use PCR as the modelling or lm. Default is lm
    # PComps is the number of principal components. Default is assumed number of covariates
    # sim.metrics determines whether or not to calculate similarity measures---slower
  # model determines whether raw data is attached
  # meanSamp indicates whether to sample the covariate means for the similarity measure -- faster but less precise

    source("fatTrim.R") # to reduce model size
    source("similarity.metrics.R") # similarity metrics

    if( pcr.model == TRUE ){
      ssl <- "pcr"
      library(pls) # load package for PCR
    }else{
      ssl <- "lm"
    }

    data <- as.data.frame(data)
    original.studies <- unique(data$Study)
    if( anyNA(sim.covs) ){
      # if not specified use all the covariates (assuming the first two columns are Study and Y)
      sim.covs <- seq(1, ncol(data) )[-c(1,2)]
    }

    target.sim.covs <- sim.covs - 2 # the target study does not have Study and outcome (Y) columns
    # so shift indices over by 2

    mean.target.covs <- colMeans(target.study[,target.sim.covs]) # mean covariates of target study

    # rename studies as integers in order from 1:length(unique(data$Study))
    study.mat <- matrix(nrow = length(unique(data$Study)), ncol = 2)
    study.mat[,1] <- unique(data$Study)
    study.mat[,2] <- 1:length(unique(data$Study))
    for ( i in 1:length(unique(data$Study)) ){
      data$Study[data$Study == study.mat[i,1] ] <- study.mat[i,2]
    }
    rm(study.mat)


    # determine number of rows in each study and produce covariate mean matrix
    sampSizes <- c()
    covMeans <- matrix(nrow = length(unique(data$Study)), ncol = length(sim.covs) ) # matrix of study means
    for (i in 1:length(unique(data$Study))){
      sampSizes <- c(sampSizes, length( data$Study[data$Study == unique(data$Study)[i] ]  ) )
      covMeans[i,] <- colMeans( data[data$Study == i, sim.covs ] )
    }

    studies <- as.integer( unique(data$Study) )
    row.list <- list(length = max.straps) # list of the rows that were included in study strap

    ss.obj <- list(models = vector("list", length = max.straps), data = c(), sim.mat <- c(),
                   strapRows <- list(),
                   dataInfo = list(studyNames = original.studies, sampleSizes = sampSizes),
                   modelInfo = list(sampling = "ar", numStraps = max.straps, SSL = ssl,
                                    pcomps = PComps, numPaths = paths,
                                     convg.vec = c(), convgCritera = converge.lim,
                                    meanSamp = meanSampling, stack.type = stack),
                   stack.coefs <- c(), simMat = c())
    class(ss.obj) <- "ss"
    convgVec <- c() # each element is the number of candidate straps before acceptance

    # similarity matrix contains the average covariates that are specified
    similarity.matrix <- matrix(ncol = 23, nrow = max.straps)  # similarity metrics

    if( !is.function(sim.fn) ){
      # use default similarity function if none provided
      sim.fn <- function(dat1, dat2){
        return( abs(cor(colMeans(dat1), colMeans(dat2))) )
      }
    }
#######-----------------------------------------------------

    rpts <- 1 # number of repeated paths
    z <- 0
    sim.metric <- 0 # arbitrarily small
    convgVec <- c()
    while(rpts <= paths && z <= max.straps){

      message(paste0("Study Strap: ", z + 1, ", Path: ", rpts))

      counter <- 0 # reset counter at each new sample

      ########################
      ######## Boostraping
      ########################

      sim <- 0 # this is an indicator telling the while loop to break (if = 1)
      repeat.break <- 0
      total.straps <- 0 # this tracks total number of candidate straps
      while (sim == 0 && repeat.break == 0){ #while loop for restrapping: breaks for either acceptance (sim) or accpetance counter limit (converge.lim)

        if (counter >= converge.lim){
          counter <- 0
          sim.metric <- 0 # arbitrarily large
          rpts <- rpts + 1
          repeat.break <- 1
        }

        ########################
        ######## Study Bag
        ########################
        bag <- sample.int(length(studies), bag.size, replace = TRUE)
        strap.table <- as.data.frame(table(bag)) # put in data table format

        #####################################################################
        # Study Strap Sampling
        #####################################################################
        if( meanSampling == TRUE){
          # use means to determine similarity meausre to speed up AR sampling
          current.sim.metric <- sim.fn( target.study[,target.sim.covs],
                                        covMeans[bag,])

        }else{
          indx <- c() # vector of indices corresponding to rows being sub-sampled

          for (i in 1:nrow(strap.table)) {
            elec.indx <- which(data$Study == as.numeric(as.character(strap.table[i, 1]))) # rows corresponding to electrode sampled in current bag
            elec.obs <- round(length(elec.indx) / bag.size * as.numeric(as.character(strap.table[i, 2])))# number of rows to sample times the number of times the electrode shows up in the study strap generator. Divide rows of current electrode by the bag.size (14 electrodes)
            rows.samp <- sample(elec.indx, elec.obs, replace = FALSE)
            indx <- c(indx, rows.samp) # sample as many rows as indicated in elec.obs and add to indices vector

          }

          rm(elec.indx)
          rm(rows.samp)
          ########################
          # similarity measure
          ########################
          current.sim.metric <- sim.fn( target.study[,target.sim.covs],
                                        data[indx, sim.covs] )
        }

        ########################
        # accept/reject step
        ########################

        if(current.sim.metric >=  sim.metric){
          # test to see if the similarity metric is at least as good as before
          sim.metric <- current.sim.metric # set the current similarity metric to the current metric
          counter <- counter + 1
          z <- z + 1 # current accepted pseudo electrode counter
          total.straps <- total.straps + 1 # add to total straps
          sim <- 1 # break the while loop

        }else{
          # if it isn't keep testing new study straps
          counter <- counter + 1
          total.straps <- total.straps + 1 # add to total straps
        }

      }

      #-------------------------------------------------------------------------

      # only fit classifier if the while loop above was broken because of an acceptance
      # i.e., SKIP remaking electrode and fitting classifier if while loop was broken because it reached convergence limit
      if(counter < converge.lim){

        if( meanSampling == TRUE){
          # need to sample study strap if used meanSampling
          indx <- c() # vector of indices corresponding to rows being sub-sampled

          for (i in 1:nrow(strap.table)) {
            elec.indx <- which(data$Study == as.numeric(as.character(strap.table[i, 1]))) # rows corresponding to electrode sampled in current bag
            elec.obs <- round(length(elec.indx) / bag.size * as.numeric(as.character(strap.table[i, 2])))# number of rows to sample times the number of times the electrode shows up in the study strap generator. Divide rows of current electrode by the bag.size (14 electrodes)
            rows.samp <- sample(elec.indx, elec.obs, replace = FALSE)
            indx <- c(indx, rows.samp) # sample as many rows as indicated in elec.obs and add to indices vector

          }
          rm(elec.indx)
          rm(rows.samp)
        }

        row.list[[z]] <- indx # rows corresponding to current study strap
        convgVec <- c(convgVec, counter) # add number of candidate study straps before convergence

        #########################################
        # Full Classifier for Study Strap
        #########################################
        if(pcr.model == TRUE){
          model.fit <- pcr(formula, data = data[indx, -1], model = FALSE, ncomp = PComps) # fit classifier with PCR
        }else{
          model.fit <- lm(formula, data = data[indx, -1], model = FALSE) # fit classifier with lm

        }
        ss.obj$models[[z]] <- fatTrim(model.fit) # save memory and add model to object to be outputted

        if ( sim.mets == TRUE ){
          # if sim.metrics is provided by user, then calculate metrics to generate CPS weights
          similarity.matrix[z, ] <- sim.metrics(target.study[,target.sim.covs], data[indx, sim.covs])
        }


      }
    }
    #mapply(c, first, second, SIMPLIFY=FALSE)
        ##############
        # Stacking
        ##############

        library(nnls) # fits stacking model

        if (stack == "ss") {
            row.list <- unlist(row.list) # vectorize rows of all study straps

            # stacking regression matrix
            stack.mat <- matrix(ncol = z + 1, nrow = length(row.list))
            stack.mat[, 1] <- data$Y[row.list] # add labels

            for (SSL in 1:z ) {

                if( pcr.model == TRUE){
                  stack.mat[, SSL + 1] <- predict(ss.obj$models[[SSL]],
                                                  data[row.list,], ncomp = PComps)
                }else{
                  stack.mat[, SSL + 1] <- predict(ss.obj$models[[SSL]],
                                                  data[row.list,])
                }

            }

            ss.obj$stack.coefs <- coef(nnls(A = as.matrix(cbind(1, stack.mat[, -1])),
                          b = as.matrix(stack.mat[, 1])))

        } else if (stack == "standard") {
            stack.mat <- matrix(ncol = z + 1, nrow = nrow(data))
            stack.mat[, 1] <- data$Y # add labels

            for (SSL in 1:z ){

                if(pcr.model == TRUE){
                  stack.mat[, SSL + 1] <- predict(ss.obj$models[[SSL]],
                                                  data, ncomp = PComps)
                }else{
                  stack.mat[, SSL + 1] <- predict(ss.obj$models[[SSL]],
                                                  data)
                }
            }

            ss.obj$stack.coefs <- coef(nnls(A = as.matrix(cbind( 1, stack.mat[, -1])),
                                            b = as.matrix(stack.mat[, 1])))

        }

        rm(stack.mat)
        if(model == TRUE){
          ss.obj$data <- data
        }

        ss.obj$strapRows <- row.list # rows of each observation in corresponding study strap
        ss.obj$modelInfo$convg.vec <- convgVec # vector of candidate straps before acceptance
        ss.obj$models <- ss.obj$models[ lapply(ss.obj$models, length) > 0 ] # remove elements of list that are empty
        ss.obj$modelInfo$numStraps <- z

        # generate CPSW weights
        if( !anyNA(target.study) ){
          # if a target study is provided generate matrix of CPS weights
          similarity.matrix <- abs(similarity.matrix) / rowMeans( abs(similarity.matrix) )
          # each column is a vector of weights that could be used to weight the study strap predictions
          colnames(similarity.matrix) <- c("Matcor Diag", "Matcor Sum", "Matcor Sum Abs", "|rho|",
                                           "rho sq", "UV rho sq", "UV cov sq", "UV rho", "UV cov",
                                           "diag UV rho sq", "diag UV cov", "diag UV cov sq", "Mean Corr",
                                           "SMI", "RV", "RV2", "RVadj", "PSI", "r1", "r2", "r3", "r4", "GCD")
          rownames(similarity.matrix) <- paste0("SS_", 1:max.straps) # each row corresponds to a study strap
          ss.obj$simMat <- similarity.matrix[1:z,] # matrix of similarity measures: remove rows with NAs
        }

    return(ss.obj)
}

#
#  #####-----------------------------------------------
#
#         bagRows.list <- list(NA) # each element is a vector of row indices of full that are accepted straps in AR
#         # accept reject step
#         counter <- 0 # number of samples before acceptance
#         strap <- 1 # strap counter within path
#         total.straps <- 1 # the total number of straps across all paths
#         thresh <-  5e+14 # restart value: arbitraily large starting threshold
#         threshold <- thresh # start at restart value
#         distance.matrix <- matrix(NA, ncol = 5, nrow = 500) # arbitrarily large number of rows
#         colnames(distance.matrix) <- c("Strap", "Distance", "Count", "Path", "Time")
#         path.straps <- vector(length = paths) # total number of straps in each path
#         for( path in 1:paths){
#
#             timeStart <- Sys.time()
#             print(paste0("path ", path))
#             # iterate through number of paths
#             while (counter < converge.lim){ #while loop for restrapping: breaks for either acceptance (sim) or accpetance counter limit (converge.lim)
#
#                 # Choose electrodes to be in bag:
#
#                 bag <- sample(elecs, bag.size, replace = TRUE) # sample bag
#                 feats <- wiggle.fn( colMeans( full.CVs[bag, ]) ) # calculate inflection points
#                 current.dist <- sum(  (feats - elec.target)^2  ) # squared Euclidean Distance between inflection points
#                 strap.table <- as.data.frame(table(bag)) #sample with replacement and put in data table format
#
#                 if(current.dist < threshold ){
#                     #if accepted: generate study strap row indices
#
#                     ########################################
#                     # remake pseudo study
#                     ########################################
#                     indx <- c() # vector of indices corresponding to rows being sub-sampled
#                     for(i in 1:nrow(strap.table)){
#
#                         sub.elec <- as.numeric(as.character(strap.table[i,1])) # current electrode being sampled from
#                         elec.indx <- which(full$Electrode == sub.elec) # rows corresponding to electrode sampled in current bag
#                         num.obs <- round( (length(elec.indx) / bag.size) * as.numeric(as.character(strap.table[i,2])) )
#                         elec.indx <- elec.indx[sample(1:length(elec.indx), num.obs, replace = FALSE)] #sub-sample rows
#                         indx <- c(indx, elec.indx ) # sample as many rows as indicated in elec.obs and add to indices vector
#                     }
#
#                     bagRows.list[[strap]] <- indx
#                     rm(elec.indx)
#                     rm(indx)
#                     ###########################################
#
#                     counter <- 0 # reset counter
#                     strap <- strap + 1 # increase straps of current path
#                     total.straps <- total.straps + 1 # increase total straps
#                     threshold <- current.dist
#                 }else{
#                     # add counter
#                     counter <- counter + 1
#                 }
#
#             }
#
#             timeEnd <- Sys.time()
#             path.time <- as.numeric( difftime(timeEnd, timeStart, units='mins') )
#             print(paste0("path ", path, "_elec_", test.elec, "_time_", path.time))
#             # add optimum - counter = 0 so we know which is from optimization
#
#             path.straps[path] <- strap # save the total number of straps in this path
#             strap <- 1 # reset strap counter for this bag
#             threshold <- thresh # restart threshold
#             counter <- 1
#             total.straps <- total.straps + 1
#         }
#
#     return( bagRows.list )
#
# }
#
