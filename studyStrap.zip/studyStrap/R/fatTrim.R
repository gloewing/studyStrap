#' fatTrim: Supporting function to reduce the size of models
#'
#' @param model A model object.
#' @return A model object.
#' @examples
#' set.seed(1)
#'
#' ##########################
#' ##### Simulate Data ######
#' ##########################
#'
#' # create training dataset with 10 studies, 2 covariates
#' X <- matrix(rnorm(2000), ncol = 2)
#'
#' # true beta coefficients
#' B <- c(5, 10, 15)
#'
#' # outcome vector
#' y <- cbind(1, X) %*% B
#'
#' # study names
#' study <- sample.int(10, 1000, replace = TRUE)
#' data <- data.frame( Study = study,
#'                     Y = y,
#'                     V1 = X[,1],
#'                     V2 = X[,2] )
#'
#' ##########################
#' ##### Model Fitting #####
#' ##########################
#'
#' # Fit model with 1 Single-Study Learner (SSL): PCA Regression
#' mod1 <- lm(formula = Y ~., data = data)
#'
#'
#' ############################################
#' ##### Fat Trim to reduce model size #####
#' ############################################
#'
#' mod1.trim <- fatTrim(mod1)
#'
#' # compare sizes
#' object.size(mod1)
#' object.size(mod1.trim)
#' @export


fatTrim = function(cm) {
    # modified from http://www.win-vector.com/blog/2014/05/trimming-the-fat-from-glm-models-in-r/
    cm$y = c()
    cm$model = c()
    cm$residuals = c()
    cm$fitted.values = c()
    cm$effects = c()
    cm$scores = c()
    cm$loadings = c()
    cm$weights = c()
    cm$Yloadings = c()
    cm$Xtotvar = c()
    cm$trainingData = c()
    cm$resample = c()
    cm$results = c()
    #cm$control = c()
    cm$dots = c()
    cm$times = c()


    attr(cm$terms,".Environment") = c()
    attr(cm$formula,".Environment") = c()


    cm
}
